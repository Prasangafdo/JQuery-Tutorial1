# JQuery-Tutorial1
JQuery Beginner tutorial (Series 1)
*Boostraps included
*Template folder contains a template of a registration form. 
